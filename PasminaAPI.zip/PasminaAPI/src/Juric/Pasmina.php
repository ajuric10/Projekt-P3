<?php

namespace Juric;

/**
 * @Entity @Table(name="pasmina")
 **/


class Pasmina
{
    /** @id @Column(type="integer") @GeneratedValue **/
    protected $sifra;

    /**
    * @Column(type="string")
    */
    private $nazivPasmine;

     /**
    * @Column(type="string")
    */
    private $kategorijaVelicine;


    /**
    * @Column(type="string")
    */
    private $zivotniVijek;

     /**
    * @Column(type="string")
    */
    private $drzava; 

    /**
    * @Column(type="string")
    */
    private $sveAnotacije;

    public function getSifra(){
      return $this->sifra;
    }
  
    public function setSifra($sifra){
      $this->sifra = $sifra;
    }
  
    public function getNazivPasmine(){
      return $this->nazivPasmine;
    }
  
    public function setNazivPasmine($nazivPasmine){
      $this->nazivPasmine = $nazivPasmine;
    }
  
    public function getKategorijaVelicine(){
      return $this->kategorijaVelicine;
    }
  
    public function setKategorijaVelicine($kategorijaVelicine){
      $this->kategorijaVelicine = $kategorijaVelicine;
    }
  
    public function getZivotniVijek(){
      return $this->zivotniVijek;
    }
  
    public function setZivotniVijek($zivotniVijek){
      $this->zivotniVijek = $zivotniVijek;
    }
  
    public function getDrzava(){
      return $this->drzava;
    }
  
    public function setDrzava($drzava){
      $this->drzava = $drzava;
    }
  
    public function getSveAnotacije(){
      return $this->sveAnotacije;
    }
  
    public function setSveAnotacije($sveAnotacije){
      $this->sveAnotacije = $sveAnotacije;
    }

    
    
  public function setPodaci($podaci)
	{
		foreach($podaci as $kljuc => $vrijednost){
			$this->{$kljuc} = $vrijednost;
		}
	}

}



?>
