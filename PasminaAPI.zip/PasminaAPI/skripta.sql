create database ajuric_20_20 default character set utf8;
use ajuric_20_20;
create table pasmina(
    sifra int not null primary key auto_increment,
    nazivPasmine varchar(255) not null,
    kategorijaVelicine varchar(255) not null,
    zivotniVijek varchar(255) not null,
    drzava varchar(255) not null,
    sveAnotacije varchar(255) not null
);
insert into pasmina(nazivPasmine, kategorijaVelicine, zivotniVijek, drzava, sveAnotacije) 
values ("Test", "Test", "Test", "Test", "Test");
